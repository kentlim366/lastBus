﻿using System.Collections.Generic;
using System.Linq;
using BusTicketingSystem.Models;

namespace BusTicketingSystem.Repositories
{
    public class ConductorRepository : IConductorRepository
    {
        private List<Conductor> _conductors = new List<Conductor>
        {
            new Conductor
            {
                ID = "conductor",
                Name = "Conductor",
                Password = "conductor123"
            }
        };

        public Conductor GetConductorById(string conductorId)
        {
            return _conductors.FirstOrDefault(c => c.ID == conductorId);
        }

        public void AddConductor(Conductor conductor)
        {
            if (conductor != null)
            {
                _conductors.Add(conductor);
            }
        }
    }
}