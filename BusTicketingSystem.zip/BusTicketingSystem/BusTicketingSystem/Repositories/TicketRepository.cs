﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BusTicketingSystem.Repositories
{
    public class TicketRepository : ITicketRepository
    {
        private List<Models.Ticket> _tickets = new List<Models.Ticket>();

        public void AddTicket(Models.Ticket ticket)
        {
            if (ticket != null)
            {
                _tickets.Add(ticket);
            }
        }

        public List<Models.Ticket> GetTicketsByDate(DateTime date)
        {
            return _tickets.Where(t => t.DateIssued.Date == date.Date).ToList();
        }

        public List<Models.Ticket> GetTicketsByConductorAndDate(string conductorId, DateTime date)
        {
            return _tickets.Where(t => t.ConductorId == conductorId && t.DateIssued.Date == date.Date).ToList();
        }

        public Models.Ticket GetTicketById(string ticketId)
        {
            return _tickets.FirstOrDefault(t => t.ID == ticketId);
        }

        public List<Models.Ticket> GetAllTickets()
        {
            return new List<Models.Ticket>(_tickets);
        }
    }
}
