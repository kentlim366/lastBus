﻿using System.Collections.Generic;
using System.Linq;

namespace BusTicketingSystem.Repositories
{
    public class RouteRepository : IRouteRepository
    {
        private List<Models.Route> _routes = new List<Models.Route>();

        public Models.Route GetRouteByName(string routeName)
        {
            return _routes.FirstOrDefault(r => r.Name == routeName);
        }

        public void AddRoute(Models.Route route)
        {
            if (route != null)
            {
                _routes.Add(route);
            }
        }
    }
}
