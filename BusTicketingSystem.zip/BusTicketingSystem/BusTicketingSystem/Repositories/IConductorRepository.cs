﻿namespace BusTicketingSystem.Repositories
{
    public interface IConductorRepository
    {
        Models.Conductor GetConductorById(string conductorId);
        void AddConductor(Models.Conductor conductor);
    }
}
