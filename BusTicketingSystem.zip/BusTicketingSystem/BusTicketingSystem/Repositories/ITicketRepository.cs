﻿using System;
using System.Collections.Generic;

namespace BusTicketingSystem.Repositories
{
    public interface ITicketRepository
    {
        void AddTicket(Models.Ticket ticket);
        List<Models.Ticket> GetTicketsByDate(DateTime date);
        List<Models.Ticket> GetTicketsByConductorAndDate(string conductorId, DateTime date);
        Models.Ticket GetTicketById(string ticketId);
        List<Models.Ticket> GetAllTickets();
    }
}
