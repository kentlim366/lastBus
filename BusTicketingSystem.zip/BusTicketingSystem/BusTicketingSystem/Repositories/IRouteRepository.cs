﻿namespace BusTicketingSystem.Repositories
{
    public interface IRouteRepository
    {
        Models.Route GetRouteByName(string routeName);
        void AddRoute(Models.Route route);
    }
}
