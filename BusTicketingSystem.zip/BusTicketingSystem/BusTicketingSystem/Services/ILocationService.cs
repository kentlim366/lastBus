﻿using System.Collections.Generic;

namespace BusTicketingSystem.Services
{
    public interface ILocationService
    {
        List<string> GetAllLocations();
        (double latitude, double longitude)? GetLocationCoordinates(string locationName);
        double CalculateDistance(string fromLocation, string toLocation);
        double CalculateFare(double distanceKm);
    }
}
