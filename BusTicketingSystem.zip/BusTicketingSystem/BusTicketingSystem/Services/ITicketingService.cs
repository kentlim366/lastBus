﻿using BusTicketingSystem.Models;
using System;
using System.Collections.Generic;

namespace BusTicketingSystem.Services
{
    public interface ITicketingService
    {
        Ticket CreateTicket(Ticket ticket);
        List<Ticket> GetTicketsIssuedByDate(DateTime date);
        List<Ticket> GetAllTickets();
        List<Ticket> GetConductorTickets(string conductorId, DateTime date);
        Ticket GetTicketById(string ticketId);
        bool UpdateTicket(Ticket ticket);
        bool DeleteTicket(string ticketId);
        bool AuthenticateConductor(string conductorId, string password);
        Conductor GetConductor(string conductorId);
        List<string> GetLocationsByRoute(string routeName);
        double CalculateFare(string routeName, string fromLocation, string toLocation);
        double GetDistance(string routeName, string fromLocation, string toLocation);

        // ADD THESE
        Ticket CreateAndPrintTicket(
            string conductorId,
            string routeName,
            string fromLocation,
            string toLocation);

        string GetHardwareStatus();

        bool IsHardwareAvailable();
    }
}