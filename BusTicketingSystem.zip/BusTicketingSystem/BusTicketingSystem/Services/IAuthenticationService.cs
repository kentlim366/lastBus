﻿namespace BusTicketingSystem.Services
{
    public interface IAuthenticationService
    {
        Models.User Authenticate(string username, string password);
        bool IsAuthenticated(Models.User user);
        void Logout();
    }
}
