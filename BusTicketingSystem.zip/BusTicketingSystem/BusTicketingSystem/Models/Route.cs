﻿using System;
using System.Collections.Generic;

namespace BusTicketingSystem.Models
{
    public class Route : BaseModel
    {
        public string Name { get; set; } = string.Empty;
        public Dictionary<string, double> Locations { get; set; } = new Dictionary<string, double>();

        public Route()
        {
        }

        public Route(string name)
        {
            ID = name;
            Name = name;
        }

        public void AddLocation(string locationName, double distanceFromStart)
        {
            Locations[locationName] = distanceFromStart;
        }

        public double GetDistance(string fromLocation, string toLocation)
        {
            if (Locations.TryGetValue(fromLocation, out var fromDistance) &&
                Locations.TryGetValue(toLocation, out var toDistance))
            {
                return Math.Abs(toDistance - fromDistance);
            }
            return 0;
        }
    }
}
