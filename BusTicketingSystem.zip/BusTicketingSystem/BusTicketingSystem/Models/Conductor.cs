﻿using System;

namespace BusTicketingSystem.Models
{
    public class Conductor : BaseModel
    {
        public string Name { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }

        public Conductor()
        {
            CreatedAt = DateTime.Now;
        }
    }
}
