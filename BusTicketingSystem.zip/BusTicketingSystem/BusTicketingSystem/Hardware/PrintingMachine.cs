﻿using System;

namespace BusTicketingSystem.Hardware
{
    public class PrintingMachine : IDevice
    {
        private bool _isOnline = true;

        public bool IsHardwareAvailable()
        {
            return _isOnline;
        }

        public bool PrintTicket(string ticketData)
        {
            if (!_isOnline)
                return false;

            Console.WriteLine(ticketData);
            return true;
        }

        public void SetOnline(bool isOnline)
        {
            _isOnline = isOnline;
        }
    }
}